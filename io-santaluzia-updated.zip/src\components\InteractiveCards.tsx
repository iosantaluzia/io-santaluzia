import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Users, Stethoscope, Eye, Building2, Home, Calendar } from "lucide-react";

interface CardData {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  image: string;
  color: string;
  bgColor: string;
  iconBg: string;
}

const InteractiveCards = () => {
  const [activeCard, setActiveCard] = useState<string | null>(null);

  const cardsData: CardData[] = [
    {
      id: "profissionais",
      title: "Profissionais Qualificados",
      description: "Estamos prontos para cuidar da sua visão, oferecendo serviços especializados em áreas como refração, catarata, cirurgia refrativa, lentes de contato, ceratocone e oftalmopediatria. Nossa equipe é composta por médicos especialistas com vasta experiência e formação continuada.",
      icon: <Users className="h-6 w-6" />,
      image: "/lovable-uploads/6d7d13fe-03bb-4ace-89df-262bcaccb86e.png",
      color: "text-medical-primary",
      bgColor: "bg-medical-muted/30",
      iconBg: "bg-medical-primary/10"
    },
    {
      id: "exames",
      title: "Ampla Gama de Exames",
      description: "Disponibilizamos exames de ponta, para garantir um diagnóstico preciso e um tratamento adequado para cada paciente. Contamos com equipamentos de última geração como OCT, topografia corneana, microscopia especular e muitos outros.",
      icon: <Stethoscope className="h-6 w-6" />,
      image: "/lovable-uploads/oct.png",
      color: "text-medical-primary",
      bgColor: "bg-medical-muted/30",
      iconBg: "bg-medical-primary/10"
    },
    {
      id: "cirurgias",
      title: "Cirurgias Especializadas",
      description: "Realizamos cirurgias de Catarata, Ceratocone, Cirurgia Refrativa, de Lesões oculares e adaptação de lentes de contato. Utilizamos as mais modernas técnicas cirúrgicas e equipamentos de alta precisão para garantir os melhores resultados.",
      icon: <Eye className="h-6 w-6" />,
      image: "/lovable-uploads/refrativacc.jpg",
      color: "text-medical-primary",
      bgColor: "bg-medical-muted/30",
      iconBg: "bg-medical-primary/10"
    }
  ];

  return (
    <div className="w-full">
      {/* Desktop Layout */}
      <div className="hidden lg:block">
        <div className="flex gap-4 h-80">
          {cardsData.map((card, index) => (
            <motion.div
              key={card.id}
              className={`relative overflow-hidden rounded-2xl cursor-pointer transition-all duration-500 ${
                activeCard === card.id ? 'flex-[2]' : 'flex-1'
              }`}
              onClick={() => setActiveCard(activeCard === card.id ? null : card.id)}
              whileHover={{ scale: 1.02 }}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              {/* Background Image */}
              <div className="absolute inset-0">
                <img
                  src={card.image}
                  alt={card.title}
                  className={`w-full h-full object-cover transition-all duration-500 ${
                    activeCard === card.id ? 'scale-105' : 'scale-100'
                  }`}
                />
                {/* Overlay */}
                <div className={`absolute inset-0 transition-opacity duration-500 ${
                  activeCard === card.id ? 'opacity-20' : 'opacity-60'
                } ${card.bgColor}`} />
              </div>

              {/* Content */}
              <div className="relative z-10 h-full flex flex-col justify-end p-6">
                {/* Icon and Title */}
                <div className={`flex items-center gap-3 mb-4 transition-all duration-500 ${
                  activeCard === card.id ? 'opacity-0' : 'opacity-100'
                }`}>
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${card.iconBg} ${card.color}`} style={{ filter: 'drop-shadow(2px 2px 0 white) drop-shadow(-2px -2px 0 white) drop-shadow(2px -2px 0 white) drop-shadow(-2px 2px 0 white)' }}>
                    {card.icon}
                  </div>
                  <span className={`font-semibold text-lg ${card.color}`} style={{ textShadow: '2px 2px 0 white, -2px -2px 0 white, 2px -2px 0 white, -2px 2px 0 white' }}>
                    {card.title}
                  </span>
                </div>

                {/* Expanded Content */}
                <AnimatePresence>
                  {activeCard === card.id && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 20 }}
                      transition={{ duration: 0.3 }}
                      className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-lg"
                    >
                      <div className="flex items-start gap-4">
                        <div className={`w-16 h-16 rounded-full flex items-center justify-center ${card.iconBg} ${card.color} flex-shrink-0`} style={{ filter: 'drop-shadow(2px 2px 0 white) drop-shadow(-2px -2px 0 white) drop-shadow(2px -2px 0 white) drop-shadow(-2px 2px 0 white)' }}>
                          {card.icon}
                        </div>
                        <div className="flex-1">
                          <h3 className={`text-2xl font-bold ${card.color} mb-3`} style={{ textShadow: '2px 2px 0 white, -2px -2px 0 white, 2px -2px 0 white, -2px 2px 0 white' }}>
                            {card.title}
                          </h3>
                          <p className="text-gray-700 leading-relaxed text-sm">
                            {card.description}
                          </p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Mobile Layout */}
      <div className="lg:hidden space-y-4">
        {cardsData.map((card, index) => (
          <motion.div
            key={card.id}
            className="relative overflow-hidden rounded-2xl cursor-pointer"
            onClick={() => setActiveCard(activeCard === card.id ? null : card.id)}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            {/* Background Image */}
            <div className="relative h-48">
              <img
                src={card.image}
                alt={card.title}
                className="w-full h-full object-cover"
              />
              {/* Overlay */}
              <div className={`absolute inset-0 ${card.bgColor} opacity-60`} />
              
              {/* Content */}
              <div className="absolute inset-0 flex items-center justify-between p-6">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${card.iconBg} ${card.color}`} style={{ filter: 'drop-shadow(2px 2px 0 white) drop-shadow(-2px -2px 0 white) drop-shadow(2px -2px 0 white) drop-shadow(-2px 2px 0 white)' }}>
                    {card.icon}
                  </div>
                  <span className={`font-semibold text-lg ${card.color}`} style={{ textShadow: '2px 2px 0 white, -2px -2px 0 white, 2px -2px 0 white, -2px 2px 0 white' }}>
                    {card.title}
                  </span>
                </div>
                <motion.div
                  animate={{ rotate: activeCard === card.id ? 180 : 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <svg
                    className="w-6 h-6 text-white"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </motion.div>
              </div>
            </div>

            {/* Expanded Content */}
            <AnimatePresence>
              {activeCard === card.id && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="bg-white p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center ${card.iconBg} ${card.color}`}>
                        {card.icon}
                      </div>
                      <h3 className={`text-xl font-bold ${card.color}`} style={{ textShadow: '2px 2px 0 white, -2px -2px 0 white, 2px -2px 0 white, -2px 2px 0 white' }}>
                        {card.title}
                      </h3>
                    </div>
                    <p className="text-gray-700 leading-relaxed">
                      {card.description}
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default InteractiveCards;
