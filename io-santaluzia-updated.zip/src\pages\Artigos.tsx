
import React, { useState } from "react";
import NavigationHeader from "@/components/NavigationHeader";
import ArticleModal from "@/components/ArticleModal";
import WhatsAppButton from "@/components/WhatsAppButton";
import { Footer } from "@/components/ui/footer";
import { Instagram, Facebook } from "lucide-react";

const Artigos = () => {
  const [selectedArticle, setSelectedArticle] = useState<any>(null);

  const artigos = [
    {
      titulo: "Cirurgia Refrativa – Liberdade e Segurança",
      subtitulo: "Os benefícios da cirurgia refrativa para sua qualidade de vida",
      data: "26 de fevereiro de 2025",
      imagem: "/lovable-uploads/87125f62-3c4e-4acc-970b-25f7eb624ae5.png",
      conteudo: "A cirurgia refrativa tem como objetivo reestabelecer a qualidade de vida dos pacientes e proporcionar a liberdade de óculos e lentes de contato.\n\nNo Instituto de Olhos Santa Luzia contamos com técnicas avançadas e atualmente o mais novo Excimer Laser de Mato Grosso, o MEL 90 da Zeiss, realizando procedimentos para correção de problemas como hipermetropia, miopia, astigmatismo e presbiopia.\n\nA cirurgia tem recuperação rápida, com resultados visíveis em pouco tempo, proporcionando maior conforto e liberdade para o paciente no seu dia a dia.\n\nCom ela é possível reduzir ou até mesmo eliminar a dependência de óculos ou lentes de contato, trazendo uma nova perspectiva de vida com mais clareza e liberdade.\n\nOs procedimentos são realizados com a mais alta tecnologia e segurança, garantindo resultados excepcionais para nossos pacientes."
    },
    {
      titulo: "Seu filho tem miopia? Saiba os riscos e tratamentos",
      subtitulo: "A miopia infantil tem aumentado e requer atenção especial dos pais",
      data: "14 de agosto de 2024",
      imagem: "/lovable-uploads/miopia.png",
      conteudo: "A miopia é um dos problemas visuais mais comuns em crianças e sua incidência tem aumentado nos últimos anos. Caracterizada pela dificuldade em enxergar objetos distantes com clareza, a miopia ocorre quando o olho é mais longo do que o normal, fazendo com que a luz se concentre antes da retina.\n\nÉ fundamental que os pais estejam atentos aos sinais que podem indicar miopia em crianças, como apertar os olhos para ver melhor, sentar muito próximo à televisão, reclamações de dor de cabeça após atividades que exigem visão de longe, e dificuldades na escola.\n\nO tratamento precoce é essencial para evitar a progressão da miopia e suas complicações. Existem várias opções de tratamento disponíveis, desde óculos e lentes de contato até tratamentos mais específicos para controle da progressão.\n\nO acompanhamento regular com um oftalmologista especializado é fundamental para monitorar a evolução da miopia e ajustar o tratamento conforme necessário."
    },
    {
      titulo: "Ceratocone: Diagnóstico Precoce é Fundamental",
      subtitulo: "Entenda os sinais e sintomas do ceratocone e a importância do tratamento",
      data: "10 de janeiro de 2025",
      imagem: "/lovable-uploads/369272fd-578e-479c-b7a6-6985adecfa00.png",
      conteudo: "O ceratocone é uma doença ocular progressiva que afeta a córnea, causando sua deformação e consequente perda da qualidade visual. O diagnóstico precoce é fundamental para evitar a progressão da doença e preservar a visão do paciente.\n\nOs principais sintomas incluem visão embaçada, sensibilidade à luz, dificuldade para dirigir à noite e necessidade frequente de trocar os óculos. O tratamento pode incluir desde óculos especiais até transplante de córnea em casos mais avançados.\n\nCom o avanço da tecnologia, hoje temos opções como crosslinking corneano e anéis intracorneanos que podem estabilizar a doença e melhorar a qualidade visual.\n\nO acompanhamento regular com exames especializados como topografia corneana é essencial para monitorar a evolução da doença."
    },
    {
      titulo: "Catarata: Quando Operar?",
      subtitulo: "Saiba tudo sobre a cirurgia de catarata e seus benefícios",
      data: "5 de dezembro de 2024",
      imagem: "/lovable-uploads/6d7d13fe-03bb-4ace-89df-262bcaccb86e.png",
      conteudo: "A catarata é uma das principais causas de cegueira reversível no mundo e afeta principalmente pessoas acima de 60 anos. A cirurgia de catarata é um procedimento seguro e eficaz que pode restaurar completamente a visão.\n\nCom a tecnologia moderna, a cirurgia é realizada com anestesia local, tem recuperação rápida e permite ao paciente retomar suas atividades normais em poucos dias. A escolha da lente intraocular adequada é fundamental para o sucesso do procedimento.\n\nOs sintomas incluem visão embaçada, sensibilidade à luz, dificuldade para enxergar à noite e alteração na percepção das cores. Quando esses sintomas começam a interferir nas atividades diárias, é hora de considerar a cirurgia.\n\nA cirurgia de catarata é um dos procedimentos mais seguros e eficazes da medicina moderna, com altíssima taxa de sucesso."
    },
    {
      titulo: "Exames Oftalmológicos Essenciais",
      subtitulo: "Conheça os principais exames para manter a saúde dos seus olhos",
      data: "20 de novembro de 2024",
      imagem: "/lovable-uploads/examesessenciais.png",
      conteudo: "Os exames oftalmológicos regulares são fundamentais para detectar precocemente problemas visuais e doenças oculares. Entre os exames mais importantes estão a refração, fundo de olho, pressão intraocular e topografia corneana.\n\nNo Instituto de Olhos Santa Luzia, contamos com equipamentos de última geração para realizar diagnósticos precisos e tratamentos eficazes. A frequência dos exames deve ser determinada pelo oftalmologista baseada na idade e histórico do paciente.\n\nExames como OCT (Tomografia de Coerência Óptica), campimetria e microscopia especular são essenciais para o diagnóstico de diversas condições oculares.\n\nA prevenção é sempre o melhor tratamento, por isso recomendamos exames regulares mesmo na ausência de sintomas."
    },
    {
      titulo: "Lentes de Contato: Cuidados Essenciais",
      subtitulo: "Aprenda como usar lentes de contato com segurança e conforto",
      data: "15 de outubro de 2024",
      imagem: "/lovable-uploads/Lentes de Contato Cuidados Essenciais.png",
      conteudo: "As lentes de contato são uma excelente alternativa aos óculos, mas requerem cuidados específicos para evitar complicações. A higiene adequada, o tempo de uso correto e o acompanhamento oftalmológico regular são essenciais.\n\nÉ importante nunca dormir com lentes de contato, usar soluções adequadas para limpeza e armazenamento, e fazer exames regulares para verificar a saúde da córnea. O uso incorreto pode levar a infecções e outras complicações sérias.\n\nExistem diferentes tipos de lentes de contato: gelatinosas, rígidas, tóricas para astigmatismo e multifocais para presbiopia. A escolha deve ser feita com orientação médica.\n\nSinais de alerta incluem olhos vermelhos, dor, sensação de corpo estranho e visão embaçada. Nestes casos, é importante remover as lentes imediatamente e procurar um oftalmologista."
    },
    {
      titulo: "Glaucoma: O Ladrão Silencioso da Visão",
      subtitulo: "Entenda os riscos do glaucoma e a importância do diagnóstico precoce",
      data: "8 de setembro de 2024",
      imagem: "/lovable-uploads/campimetro.png",
      conteudo: "O glaucoma é conhecido como o 'ladrão silencioso da visão' porque geralmente não apresenta sintomas até que já tenha causado danos irreversíveis. É uma das principais causas de cegueira no mundo e afeta principalmente pessoas acima de 40 anos.\n\nO glaucoma ocorre quando há aumento da pressão intraocular, danificando o nervo óptico. Os fatores de risco incluem idade avançada, histórico familiar, diabetes e hipertensão arterial.\n\nO tratamento pode incluir colírios para reduzir a pressão ocular, laser ou cirurgia em casos mais avançados. O diagnóstico precoce através de exames regulares é fundamental para preservar a visão.\n\nExistem diferentes tipos de glaucoma: de ângulo aberto (mais comum), de ângulo fechado e congênito. Cada tipo requer abordagem específica de tratamento."
    },
    {
      titulo: "Presbiopia: A Vista Cansada dos 40",
      subtitulo: "Saiba tudo sobre a presbiopia e as opções de tratamento disponíveis",
      data: "22 de julho de 2024",
      imagem: "/lovable-uploads/refrativacc.jpg",
      conteudo: "A presbiopia, popularmente conhecida como 'vista cansada', é uma condição natural que afeta todas as pessoas a partir dos 40 anos. Ela ocorre devido ao envelhecimento do cristalino, que perde sua capacidade de focar objetos próximos.\n\nOs sintomas incluem dificuldade para ler textos pequenos, necessidade de afastar objetos para enxergá-los melhor e fadiga visual após atividades que exigem visão de perto.\n\nAs opções de tratamento incluem óculos para leitura, lentes bifocais ou multifocais, lentes de contato especiais e cirurgia refrativa. A escolha do tratamento deve ser feita em conjunto com o oftalmologista.\n\nA presbiopia é progressiva e tende a estabilizar por volta dos 60 anos. Durante este período, pode ser necessário ajustar a correção periodicamente."
    },
    {
      titulo: "Astigmatismo: Visão Distorcida",
      subtitulo: "Entenda o que é astigmatismo e como corrigi-lo",
      data: "3 de junho de 2024",
      imagem: "/lovable-uploads/topografia.png",
      conteudo: "O astigmatismo é um erro refrativo comum que ocorre quando a córnea tem uma curvatura irregular, causando visão distorcida ou embaçada tanto para perto quanto para longe. Pode estar presente desde o nascimento ou se desenvolver ao longo da vida.\n\nOs sintomas incluem visão embaçada, dificuldade para distinguir formas similares, fadiga visual e dores de cabeça. O astigmatismo pode ocorrer isoladamente ou em conjunto com miopia ou hipermetropia.\n\nA correção pode ser feita com óculos, lentes de contato tóricas ou cirurgia refrativa. O diagnóstico preciso através de exames especializados é essencial para o sucesso do tratamento.\n\nO astigmatismo pode ser corneal (mais comum) ou lenticular. A topografia corneana é fundamental para o diagnóstico preciso e planejamento do tratamento."
    },
    {
      titulo: "Hipermetropia: Dificuldade para Ver de Perto",
      subtitulo: "Conheça os sintomas e tratamentos da hipermetropia",
      data: "18 de maio de 2024",
      imagem: "/lovable-uploads/pentacam.png",
      conteudo: "A hipermetropia é um erro refrativo onde a luz é focalizada atrás da retina, causando dificuldade para enxergar objetos próximos. Em casos leves, pode não apresentar sintomas, mas em graus mais altos pode causar fadiga visual e dores de cabeça.\n\nOs sintomas incluem dificuldade para ler, escrever ou realizar tarefas que exigem visão de perto, fadiga visual após atividades prolongadas e dores de cabeça. Em crianças, pode causar estrabismo se não for corrigida adequadamente.\n\nO tratamento inclui óculos, lentes de contato ou cirurgia refrativa. Em crianças, a correção precoce é fundamental para o desenvolvimento visual adequado.\n\nA hipermetropia pode ser axial (olho menor que o normal) ou refrativa (poder refrativo insuficiente). O diagnóstico precoce em crianças é crucial para prevenir ambliopia."
    },
    {
      titulo: "Diabetes e Saúde Ocular",
      subtitulo: "Como o diabetes afeta a visão e a importância do controle glicêmico",
      data: "12 de abril de 2024",
      imagem: "/lovable-uploads/oct.png",
      conteudo: "O diabetes pode causar várias complicações oculares, sendo a retinopatia diabética a mais comum. Esta condição afeta os vasos sanguíneos da retina e pode levar à perda de visão se não for tratada adequadamente.\n\nOs fatores de risco incluem tempo de diabetes, controle glicêmico inadequado, hipertensão arterial e colesterol elevado. O controle rigoroso da glicemia é fundamental para prevenir complicações.\n\nO tratamento pode incluir laser, injeções intravítreas ou cirurgia em casos mais avançados. O acompanhamento regular com oftalmologista é essencial para todos os pacientes diabéticos.\n\nA retinopatia diabética pode ser não proliferativa (inicial) ou proliferativa (avançada). O edema macular diabético é uma complicação comum que pode ser tratada com injeções intravítreas."
    }
  ];

  return (
    <div className="min-h-screen bg-background pt-20">
      <NavigationHeader showLogo={true} />
      
      <div className="max-w-4xl mx-auto py-20 px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-5xl font-sans font-bold text-medical-primary mb-6">
            Artigos
          </h1>
          <p className="text-lg text-medical-secondary max-w-2xl mx-auto">
            Fique por dentro das novidades e informações importantes sobre saúde ocular através dos nossos artigos especializados.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          {artigos.map((artigo, index) => (
            <article 
              key={index} 
              className="bg-white rounded-lg shadow-soft overflow-hidden hover:shadow-medium transition-all duration-300 cursor-pointer"
              onClick={() => setSelectedArticle(artigo)}
            >
              <div className="h-48 overflow-hidden">
                <img 
                  src={artigo.imagem}
                  alt={artigo.titulo}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <div className="text-sm text-medical-secondary mb-2">
                  {artigo.data}
                </div>
                <h2 className="text-xl font-sans font-bold text-medical-primary mb-3 line-clamp-2">
                  {artigo.titulo}
                </h2>
                <p className="text-medical-secondary text-sm mb-4 line-clamp-3">
                  {artigo.subtitulo}
                </p>
                <button className="text-medical-primary hover:text-medical-secondary transition-colors font-medium text-sm">
                  LEIA MAIS »
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* Botão de agendamento */}
      <div className="py-12 bg-background">
        <div className="max-w-4xl mx-auto px-4 flex justify-center">
          <WhatsAppButton />
        </div>
      </div>

      {/* Footer */}
      <Footer
        logo={
          <img 
            src="/lovable-uploads/logoimg.png" 
            alt="Instituto de Olhos Santa Luzia" 
            className="h-10 w-10 brightness-0 invert"
          />
        }
        brandName="Instituto de Olhos Santa Luzia"
        socialLinks={[
          {
            icon: <Instagram className="h-5 w-5" />,
            href: "https://www.instagram.com/io.santaluzia/",
            label: "Instagram",
          },
          {
            icon: <Facebook className="h-5 w-5" />,
            href: "https://www.facebook.com/institudodeolhossantaluzia",
            label: "Facebook",
          },
        ]}
        mainLinks={[
          { href: "/instituto", label: "O Instituto" },
          { href: "/corpo-clinico", label: "Corpo Clínico" },
          { href: "/exames", label: "Exames" },
          { href: "/catarata", label: "Catarata" },
          { href: "/cirurgia-refrativa", label: "Cirurgia Refrativa" },
          { href: "/ceratocone", label: "Ceratocone" },
          { href: "/artigos", label: "Artigos" },
        ]}
        legalLinks={[
          { href: "#", label: "Política de Privacidade" },
          { href: "#", label: "Termos de Uso" },
          { href: "#", label: "LGPD" },
        ]}
        copyright={{
          text: "© 2024 Instituto de Olhos Santa Luzia",
          license: "Avenida dos Tarumãs, 930 - Sinop/MT - CEP: 78550-001 | +55 66 99721-5000",
        }}
      />

      <ArticleModal
        isOpen={!!selectedArticle}
        onClose={() => setSelectedArticle(null)}
        title={selectedArticle?.titulo || ""}
        content={selectedArticle?.conteudo || ""}
        date={selectedArticle?.data || ""}
      />
    </div>
  );
};

export default Artigos;
