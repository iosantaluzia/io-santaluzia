
import React, { useState } from "react";
import NavigationHeader from "@/components/NavigationHeader";
import ExamModal from "@/components/ExamModal";
import WhatsAppButton from "@/components/WhatsAppButton";
import FloatingWhatsAppButton from "@/components/FloatingWhatsAppButton";
import { Footer } from "@/components/ui/footer";
import { Instagram, Facebook } from "lucide-react";

const Exames = () => {
  const [selectedExam, setSelectedExam] = useState<any>(null);

  const exames = [
    {
      nome: "Microscopia Especular",
      imagem: "/lovable-uploads/microscopia.png",
      descricao: "Avaliação das células do endotélio corneano",
      descricaoDetalhada: "A microscopia especular de córnea é utilizada na oftalmologia para avaliar as células endoteliais da córnea, que são essenciais para a manutenção da transparência corneana.\n\nAo examinar as células endoteliais, os oftalmologistas podem avaliar a saúde da córnea, prever a resposta a tratamentos e monitorar a progressão de doenças ao longo do tempo.\n\nSuas indicações incluem avaliações pré e pós-operatória de cirurgias como: catarata, transplantes de córnea, indicado também para usuários crônicos de lentes de contato, implante de lentes intraoculares e no acompanhamento de doenças corneanas.\n\nÉ um exame indolor e de rápida execução. O paciente deve estar sem lentes de contato caso faça uso. Para sua realização é necessário apenas que o paciente fixe o olhar no alvo dentro do aparelho. Geralmente não necessita de acompanhantes."
    },
    {
      nome: "YAG Laser",
      imagem: "/lovable-uploads/yaglaser.png",
      descricao: "Tratamento a laser para opacificação capsular",
      descricaoDetalhada: "O YAG laser é uma ferramenta versátil e amplamente utilizada em oftalmologia, utilizado para diversas funções.\n\nApós a cirurgia de catarata, uma fina membrana chamada de cápsula posterior pode se tornar opaca, causando visão turva. Utilizamos o YAG Laser para realizar uma limpeza desta membrana, que envolve a criação de uma abertura na cápsula para restaurar a visão.\n\nEm casos de glaucoma de ângulo estreito ou fechado, onde a drenagem do humor aquoso é prejudicada, uma iridotomia pode ser realizada para criar uma pequena abertura na íris, permitindo que o líquido flua adequadamente.\n\nEle é capaz fornecer tratamentos minimamente invasivos, indolores, com tempos de recuperação mais rápidos."
    },
    {
      nome: "Topografia Corneana",
      imagem: "/lovable-uploads/topografia.png",
      descricao: "Mapeamento detalhado da curvatura da córnea",
      descricaoDetalhada: "A topografia corneana é um procedimento oftalmológico utilizado para mapear a superfície da córnea, que é a parte transparente e externa do olho.\n\nA córnea desempenha um papel fundamental na refração da luz que entra no olho, ajudando a focalizar a imagem na retina. Este exame auxilia no diagnóstico de doenças como astigmatismo, ceratocone, distrofias corneanas e irregularidades na superfície corneana.\n\nÉ especialmente importante para avaliação pré-operatória de cirurgias refrativas, diagnóstico precoce de ceratocone e acompanhamento de pacientes com lentes de contato.\n\nO exame é indolor, rápido e não invasivo, sendo realizado através de um aparelho que projeta anéis de luz na córnea e analisa sua reflexão."
    },
    {
      nome: "Pentacam",
      imagem: "/lovable-uploads/pentacam.png",
      descricao: "Análise completa do segmento anterior do olho",
      descricaoDetalhada: "O Pentacam é um dispositivo de tomografia de coerência óptica (OCT) utilizado na oftalmologia para avaliar a estrutura e topografia da córnea e segmento anterior do olho.\n\nUtilizado para avaliação pré-operatória de cirurgias refrativas como o LASIK. É importante avaliar a espessura corneana, a topografia corneana e a curvatura da córnea para determinar a adequação do paciente para o procedimento.\n\nAuxilia no diagnóstico de ceratocone e outras ectasias corneanas por fornece mapas tridimensionais detalhados da córnea, ajudando os médicos a monitorar a progressão da doença e planejar intervenções adequadas.\n\nO Pentacam também é útil na avaliação pré-operatória de pacientes que serão submetidos à implantação de lentes intraoculares após a remoção da catarata."
    },
    {
      nome: "Aberrômetro",
      imagem: "/lovable-uploads/aberrometro.png",
      descricao: "Medição de aberrações ópticas do olho",
      descricaoDetalhada: "O aberrômetro, também conhecido como wavefront analyzer, é um instrumento utilizado na oftalmologia para medir as aberrações ópticas do olho. Essas aberrações são imperfeições na forma da córnea e do cristalino que podem afetar a qualidade da visão.\n\nAvaliação pré-operatória de cirurgias refrativas: Antes de realizar cirurgias refrativas como a LASIK (cirurgia refrativa a laser), o aberrômetro é utilizado para medir e quantificar as aberrações ópticas do olho.\n\nAlém de medir as aberrações ópticas, o aberrômetro também pode avaliar a qualidade da visão do paciente em condições específicas, como luz de dia, luz noturna e diferentes níveis de contraste. Isso pode ajudar os oftalmologistas a entender melhor as necessidades visuais do paciente e planejar o tratamento adequado."
    },
    {
      nome: "Campimetria",
      imagem: "/lovable-uploads/campimetria.png",
      descricao: "Exame do campo visual periférico",
      descricaoDetalhada: "A campimetria, também conhecida como exame de campo visual, é uma ferramenta fundamental na oftalmologia para avaliar a extensão e a sensibilidade da visão periférica e central de um paciente.\n\nEste exame é frequentemente utilizado para diagnosticar e monitorar uma variedade de condições oftalmológicas e neurológicas que afetam o campo visual, principalmente o glaucoma.\n\nA campimetria também é útil na avaliação de distúrbios neurológicos que afetam o campo visual, como lesões no nervo óptico, tumores cerebrais, acidentes vasculares cerebrais (AVCs) e esclerose múltipla. Bem como o monitoramento de doenças retinianas como a retinopatia diabética, degeneração macular e retinose pigmentar.\n\nO exame é realizado em uma sala escura, onde o paciente fixa o olhar em um ponto central enquanto pequenas luzes aparecem em diferentes posições do campo visual."
    },
    {
      nome: "OCT",
      imagem: "/lovable-uploads/oct.png",
      descricao: "Tomografia de coerência óptica",
      descricaoDetalhada: "A Tomografia de Coerência Óptica (OCT) é uma técnica de imagem não invasiva que utiliza ondas de luz para capturar imagens de alta resolução das estruturas internas do olho.\n\nÉ especialmente útil para avaliar a retina, nervo óptico e segmento anterior do olho, fornecendo imagens detalhadas em seção transversal.\n\nO OCT é fundamental no diagnóstico e acompanhamento de doenças como degeneração macular relacionada à idade, retinopatia diabética, glaucoma, edema macular e outras condições que afetam a retina e o nervo óptico.\n\nO exame é rápido, indolor e não requer contato com o olho, sendo realizado através de um aparelho que emite luz infravermelha e analisa sua reflexão pelas estruturas oculares."
    }
  ];

  return (
    <div className="min-h-screen bg-background pt-20">
      <NavigationHeader showLogo={true} />
      <div className="max-w-4xl mx-auto py-20 px-4 md:px-8 lg:px-10">
        <h1 className="text-3xl md:text-5xl font-sans text-medical-primary mb-8">
          Exames Complementares
        </h1>
        <p className="text-lg text-medical-secondary max-w-3xl mx-auto mb-12">
          Oferecemos uma ampla gama de exames oftalmológicos com equipamentos de última geração para diagnósticos precisos e confiáveis.
        </p>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {exames.map((exame, index) => (
            <div 
              key={index} 
              className="group cursor-pointer bg-white rounded-lg shadow-soft overflow-hidden hover:shadow-medium transition-all duration-300"
              onClick={() => setSelectedExam(exame)}
            >
              <div className="relative h-48 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-medical-primary/80 to-transparent"></div>
                <img 
                  src={exame.imagem}
                  alt={exame.nome}
                  className="relative w-full h-full object-contain p-4 group-hover:scale-105 transition-transform duration-300 z-10"
                />
                <h3 className="absolute bottom-4 left-4 right-4 text-white font-sans text-lg font-semibold z-20">
                  {exame.nome}
                </h3>
              </div>
              <div className="p-4">
                <p className="text-medical-secondary text-sm">{exame.descricao}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Botão de agendamento */}
      <div className="py-12 bg-background">
        <div className="max-w-4xl mx-auto px-4 flex justify-center">
          <WhatsAppButton />
        </div>
      </div>

      {/* Footer */}
      <Footer
        logo={
          <img 
            src="/lovable-uploads/26442ffb-6359-4e38-a0f7-eaddfc7505f1.png" 
            alt="Instituto de Olhos Santa Luzia" 
            className="h-10 w-10 brightness-0 invert"
          />
        }
        brandName="Instituto de Olhos Santa Luzia"
        socialLinks={[
          {
            icon: <Instagram className="h-5 w-5" />,
            href: "https://www.instagram.com/io.santaluzia/",
            label: "Instagram",
          },
          {
            icon: <Facebook className="h-5 w-5" />,
            href: "https://www.facebook.com/institudodeolhossantaluzia",
            label: "Facebook",
          },
        ]}
        mainLinks={[
          { href: "/instituto", label: "O Instituto" },
          { href: "/corpo-clinico", label: "Corpo Clínico" },
          { href: "/exames", label: "Exames" },
          { href: "/catarata", label: "Catarata" },
          { href: "/artigos", label: "Artigos" },
        ]}
        legalLinks={[
          { href: "#", label: "Política de Privacidade" },
          { href: "#", label: "Termos de Uso" },
          { href: "#", label: "LGPD" },
        ]}
        copyright={{
          text: "© 2024 Instituto de Olhos Santa Luzia",
          license: "Avenida dos Tarumãs, 930 - Sinop/MT - CEP: 78550-001 | +55 66 99721-5000",
        }}
      />

      <ExamModal
        isOpen={!!selectedExam}
        onClose={() => setSelectedExam(null)}
        title={selectedExam?.nome || ""}
        content={selectedExam?.descricaoDetalhada || selectedExam?.descricao || ""}
        image={selectedExam?.imagem || ""}
      />
      <FloatingWhatsAppButton />
    </div>
  );
};

export default Exames;
