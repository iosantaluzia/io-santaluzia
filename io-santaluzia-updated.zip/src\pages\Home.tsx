
import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Users, Stethoscope, Eye, ChevronLeft, ChevronRight } from "lucide-react";
import NavigationHeader from "@/components/NavigationHeader";
import ExpandableCard from "@/components/ExpandableCard";
import InteractiveCards from "@/components/InteractiveCards";
import WhatsAppButton from "@/components/WhatsAppButton";
import FloatingWhatsAppButton from "@/components/FloatingWhatsAppButton";
import ArticleModal from "@/components/ArticleModal";
import SymptomChecker from "@/components/SymptomChecker";
import { Footer } from "@/components/ui/footer";
import { Instagram, Facebook } from "lucide-react";

const Home = () => {
  const [scrollY, setScrollY] = useState(0);
  const [showFloatingNav, setShowFloatingNav] = useState(false);
  const [selectedArticle, setSelectedArticle] = useState<any>(null);
  const [currentArticle, setCurrentArticle] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      setScrollY(currentScrollY);
      setShowFloatingNav(currentScrollY > 600);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const artigos = [
    {
      titulo: "Cirurgia Refrativa – Liberdade e Segurança",
      subtitulo: "Os benefícios da cirurgia refrativa para sua qualidade de vida",
      data: "26 de fevereiro de 2025",
      imagem: "/lovable-uploads/87125f62-3c4e-4acc-970b-25f7eb624ae5.png",
      conteudo: "A cirurgia refrativa tem como objetivo reestabelecer a qualidade de vida dos pacientes e proporcionar a liberdade de óculos e lentes de contato.\n\nNo Instituto de Olhos Santa Luzia contamos com técnicas avançadas e atualmente o mais novo Excimer Laser de Mato Grosso, o MEL 90 da Zeiss, realizando procedimentos para correção de problemas como hipermetropia, miopia, astigmatismo e presbiopia."
    },
    {
      titulo: "Seu filho tem miopia? Saiba os riscos e tratamentos",
      subtitulo: "A miopia infantil tem aumentado e requer atenção especial dos pais",
      data: "14 de agosto de 2024",
      imagem: "/lovable-uploads/miopia.png",
      conteudo: "A miopia é um dos problemas visuais mais comuns em crianças e sua incidência tem aumentado nos últimos anos. Caracterizada pela dificuldade em enxergar objetos distantes com clareza, a miopia ocorre quando o olho é mais longo do que o normal."
    },
    {
      titulo: "Ceratocone: Diagnóstico Precoce é Fundamental",
      subtitulo: "Entenda os sinais e sintomas do ceratocone e a importância do tratamento",
      data: "10 de janeiro de 2025",
      imagem: "/lovable-uploads/369272fd-578e-479c-b7a6-6985adecfa00.png",
      conteudo: "O ceratocone é uma doença ocular progressiva que afeta a córnea, causando sua deformação e consequente perda da qualidade visual. O diagnóstico precoce é fundamental para evitar a progressão da doença e preservar a visão do paciente.\n\nOs principais sintomas incluem visão embaçada, sensibilidade à luz, dificuldade para dirigir à noite e necessidade frequente de trocar os óculos. O tratamento pode incluir desde óculos especiais até transplante de córnea em casos mais avançados."
    },
    {
      titulo: "Catarata: Quando Operar?",
      subtitulo: "Saiba tudo sobre a cirurgia de catarata e seus benefícios",
      data: "5 de dezembro de 2024",
      imagem: "/lovable-uploads/6d7d13fe-03bb-4ace-89df-262bcaccb86e.png",
      conteudo: "A catarata é uma das principais causas de cegueira reversível no mundo e afeta principalmente pessoas acima de 60 anos. A cirurgia de catarata é um procedimento seguro e eficaz que pode restaurar completamente a visão.\n\nCom a tecnologia moderna, a cirurgia é realizada com anestesia local, tem recuperação rápida e permite ao paciente retomar suas atividades normais em poucos dias. A escolha da lente intraocular adequada é fundamental para o sucesso do procedimento."
    },
    {
      titulo: "Exames Oftalmológicos Essenciais",
      subtitulo: "Conheça os principais exames para manter a saúde dos seus olhos",
      data: "20 de novembro de 2024",
      imagem: "/lovable-uploads/examesessenciais.png",
      conteudo: "Os exames oftalmológicos regulares são fundamentais para detectar precocemente problemas visuais e doenças oculares. Entre os exames mais importantes estão a refração, fundo de olho, pressão intraocular e topografia corneana.\n\nNo Instituto de Olhos Santa Luzia, contamos com equipamentos de última geração para realizar diagnósticos precisos e tratamentos eficazes. A frequência dos exames deve ser determinada pelo oftalmologista baseada na idade e histórico do paciente."
    },
    {
      titulo: "Lentes de Contato: Cuidados Essenciais",
      subtitulo: "Aprenda como usar lentes de contato com segurança e conforto",
      data: "15 de outubro de 2024",
      imagem: "/lovable-uploads/Lentes de Contato Cuidados Essenciais.png",
      conteudo: "As lentes de contato são uma excelente alternativa aos óculos, mas requerem cuidados específicos para evitar complicações. A higiene adequada, o tempo de uso correto e o acompanhamento oftalmológico regular são essenciais.\n\nÉ importante nunca dormir com lentes de contato, usar soluções adequadas para limpeza e armazenamento, e fazer exames regulares para verificar a saúde da córnea. O uso incorreto pode levar a infecções e outras complicações sérias."
    },
    {
      titulo: "Glaucoma: O Ladrão Silencioso da Visão",
      subtitulo: "Entenda os riscos do glaucoma e a importância do diagnóstico precoce",
      data: "8 de setembro de 2024",
      imagem: "/lovable-uploads/campimetro.png",
      conteudo: "O glaucoma é conhecido como o 'ladrão silencioso da visão' porque geralmente não apresenta sintomas até que já tenha causado danos irreversíveis. É uma das principais causas de cegueira no mundo e afeta principalmente pessoas acima de 40 anos.\n\nO glaucoma ocorre quando há aumento da pressão intraocular, danificando o nervo óptico. Os fatores de risco incluem idade avançada, histórico familiar, diabetes e hipertensão arterial.\n\nO tratamento pode incluir colírios para reduzir a pressão ocular, laser ou cirurgia em casos mais avançados. O diagnóstico precoce através de exames regulares é fundamental para preservar a visão."
    },
    {
      titulo: "Presbiopia: A Vista Cansada dos 40",
      subtitulo: "Saiba tudo sobre a presbiopia e as opções de tratamento disponíveis",
      data: "22 de julho de 2024",
      imagem: "/lovable-uploads/refrativacc.jpg",
      conteudo: "A presbiopia, popularmente conhecida como 'vista cansada', é uma condição natural que afeta todas as pessoas a partir dos 40 anos. Ela ocorre devido ao envelhecimento do cristalino, que perde sua capacidade de focar objetos próximos.\n\nOs sintomas incluem dificuldade para ler textos pequenos, necessidade de afastar objetos para enxergá-los melhor e fadiga visual após atividades que exigem visão de perto.\n\nAs opções de tratamento incluem óculos para leitura, lentes bifocais ou multifocais, lentes de contato especiais e cirurgia refrativa. A escolha do tratamento deve ser feita em conjunto com o oftalmologista."
    },
    {
      titulo: "Astigmatismo: Visão Distorcida",
      subtitulo: "Entenda o que é astigmatismo e como corrigi-lo",
      data: "3 de junho de 2024",
      imagem: "/lovable-uploads/topografia.png",
      conteudo: "O astigmatismo é um erro refrativo comum que ocorre quando a córnea tem uma curvatura irregular, causando visão distorcida ou embaçada tanto para perto quanto para longe. Pode estar presente desde o nascimento ou se desenvolver ao longo da vida.\n\nOs sintomas incluem visão embaçada, dificuldade para distinguir formas similares, fadiga visual e dores de cabeça. O astigmatismo pode ocorrer isoladamente ou em conjunto com miopia ou hipermetropia.\n\nA correção pode ser feita com óculos, lentes de contato tóricas ou cirurgia refrativa. O diagnóstico preciso através de exames especializados é essencial para o sucesso do tratamento."
    },
    {
      titulo: "Hipermetropia: Dificuldade para Ver de Perto",
      subtitulo: "Conheça os sintomas e tratamentos da hipermetropia",
      data: "18 de maio de 2024",
      imagem: "/lovable-uploads/pentacam.png",
      conteudo: "A hipermetropia é um erro refrativo onde a luz é focalizada atrás da retina, causando dificuldade para enxergar objetos próximos. Em casos leves, pode não apresentar sintomas, mas em graus mais altos pode causar fadiga visual e dores de cabeça.\n\nOs sintomas incluem dificuldade para ler, escrever ou realizar tarefas que exigem visão de perto, fadiga visual após atividades prolongadas e dores de cabeça. Em crianças, pode causar estrabismo se não for corrigida adequadamente.\n\nO tratamento inclui óculos, lentes de contato ou cirurgia refrativa. Em crianças, a correção precoce é fundamental para o desenvolvimento visual adequado."
    },
    {
      titulo: "Diabetes e Saúde Ocular",
      subtitulo: "Como o diabetes afeta a visão e a importância do controle glicêmico",
      data: "12 de abril de 2024",
      imagem: "/lovable-uploads/oct.png",
      conteudo: "O diabetes pode causar várias complicações oculares, sendo a retinopatia diabética a mais comum. Esta condição afeta os vasos sanguíneos da retina e pode levar à perda de visão se não for tratada adequadamente.\n\nOs fatores de risco incluem tempo de diabetes, controle glicêmico inadequado, hipertensão arterial e colesterol elevado. O controle rigoroso da glicemia é fundamental para prevenir complicações.\n\nO tratamento pode incluir laser, injeções intravítreas ou cirurgia em casos mais avançados. O acompanhamento regular com oftalmologista é essencial para todos os pacientes diabéticos."
    }
  ];

  const scrollContainerRef = React.useRef<HTMLDivElement>(null);

  const nextArticle = () => {
    if (scrollContainerRef.current) {
      const container = scrollContainerRef.current;
      const cardWidth = 320; // w-80 = 320px + gap
      const scrollAmount = cardWidth + 24; // card width + gap
      container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  const prevArticle = () => {
    if (scrollContainerRef.current) {
      const container = scrollContainerRef.current;
      const cardWidth = 320; // w-80 = 320px + gap
      const scrollAmount = cardWidth + 24; // card width + gap
      container.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header flutuante - só aparece após scroll */}
      {showFloatingNav && <NavigationHeader showLogo={true} />}

      {/* Hero Section com logo principal - posicionado mais acima */}
      <motion.div
        className="flex flex-col items-center justify-center min-h-[60vh] px-4 pt-8"
        style={{
          opacity: Math.max(0, 1 - scrollY / 400),
        }}
      >
        <div className="text-center max-w-4xl mx-auto">
          <motion.img
            src="/lovable-uploads/26442ffb-6359-4e38-a0f7-eaddfc7505f1.png"
            alt="Instituto de Olhos Santa Luzia"
            className="mx-auto mb-6 max-w-xs md:max-w-sm lg:max-w-md"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          />
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="space-y-4"
          >
            <h1 className="text-2xl md:text-4xl lg:text-5xl font-sans text-medical-primary mb-6">
              Instituto de Olhos Santa Luzia
            </h1>
            <p className="text-lg md:text-xl text-medical-secondary max-w-2xl mx-auto">
              Cuidados oftalmológicos especializados com excelência e tecnologia de ponta
            </p>
          </motion.div>
          
          {/* Seção de pesquisa de sintomas */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <SymptomChecker />
          </motion.div>
        </div>
      </motion.div>

      {/* Seção Hero com Layout Rondo CLT - Background Bege */}
      <div className="relative min-h-[80vh] bg-background">
        {/* Imagem decorativa alinhada com os botões */}
        <div className="absolute inset-0 z-0 overflow-hidden flex items-start justify-start pt-4">
          <div className="w-full max-w-4xl mx-auto px-4">
            <img 
              src="/lovable-uploads/6d7d13fe-03bb-4ace-89df-262bcaccb86e.png"
              alt="Cuidados oftalmológicos especializados"
              className="w-full object-contain rounded-t-3xl transition-all duration-300"
              style={{ 
                filter: `contrast(1.05) brightness(0.98) saturate(1.05) blur(${Math.max(0, 3 - scrollY * 0.01)}px)`,
                imageRendering: 'crisp-edges'
              }}
            />
          </div>
        </div>

        {/* Imagem de fundo (bgmockhome.png) sobrepondo */}
        <div className="absolute inset-0 z-1 overflow-hidden flex items-end justify-start">
          <div className="w-full max-w-4xl mx-auto px-4">
            <img 
              src="/lovable-uploads/bgmockhome.png"
              alt="Background mock"
              className="w-full object-contain"
              style={{ filter: 'brightness(0) saturate(100%) invert(1) sepia(0.1) saturate(0.35) hue-rotate(38deg) brightness(0.98) contrast(1)' }}
            />
          </div>
        </div>

        {/* Container do texto com efeito de recorte */}
        <div className="relative z-10 min-h-[80vh] flex items-end pb-8">
          <div className="w-full max-w-4xl mx-auto px-4">
            <div className="flex flex-col items-end">
              {/* Títulos com mais espaço horizontal */}
              <div className="w-full max-w-5xl mb-8 relative z-20">
                <h2 className="text-lg md:text-xl font-medium text-gray-600 mb-2">
                  Bem vindo ao
                </h2>
                <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-medical-primary mb-6 leading-tight">
                  INSTITUTO DE OLHOS SANTA LUZIA
                </h1>
              </div>
              
              {/* Conteúdo restante - mantém largura original */}
              <div className="w-full max-w-2xl relative z-20 self-start">
                <p className="text-base md:text-lg text-gray-700 leading-relaxed mb-8">
                  Nosso compromisso é proporcionar um serviço oftalmológico de excelência, atendendo a todas as suas necessidades visuais com cuidado e precisão. Desde 2014, estamos presentes em Sinop, Mato Grosso, oferecendo atendimento completo em oftalmologia.
                </p>
                
                {/* Botões de ação */}
                <div className="flex flex-col sm:flex-row gap-4">
                  <a 
                    href="/exames" 
                    className="inline-flex items-center text-medical-primary hover:text-medical-secondary transition-colors font-medium"
                  >
                    CONHEÇA NOSSOS EXAMES →
                  </a>
                  <a 
                    href="/instituto" 
                    className="inline-flex items-center text-medical-primary hover:text-medical-secondary transition-colors font-medium"
                  >
                    SOBRE O INSTITUTO →
                  </a>
                  <a 
                    href="https://wa.me/5566997215000" 
                    className="inline-flex items-center text-medical-primary hover:text-medical-secondary transition-colors font-medium"
                  >
                    AGENDE SUA CONSULTA →
                  </a>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>

      {/* Botão de agendamento após hero */}
      <div className="py-8 bg-background">
        <div className="max-w-4xl mx-auto px-4 flex justify-center">
          <WhatsAppButton />
        </div>
      </div>

      {/* Seção O que oferecemos */}
      <div className="py-20 bg-background">
        <div className="max-w-6xl mx-auto px-4">
          {/* Header da seção */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 mb-4">
              <div className="w-12 h-0.5 bg-medical-primary"></div>
            </div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-sans text-medical-primary mb-6">
              O que <span className="text-medical-primary">oferecemos</span>
            </h2>
            <p className="text-lg md:text-xl text-medical-secondary max-w-3xl mx-auto leading-relaxed">
              Estamos aqui para cuidar da sua saúde visual com dedicação e comprometimento. 
              Entre em contato conosco para mais informações e agende sua consulta hoje mesmo. 
              Seus olhos merecem o melhor cuidado!
            </p>
          </div>
          
          {/* Cards interativos */}
          <InteractiveCards />
        </div>
      </div>

      {/* Carrossel de Artigos */}
      <div className="py-20 bg-background">
        {/* Header com largura limitada */}
        <div className="max-w-6xl mx-auto px-4 mb-8">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl md:text-3xl font-sans text-medical-primary">Últimos Artigos</h2>
            <div className="flex space-x-2">
              <button
                onClick={prevArticle}
                className="p-2 rounded-full bg-white shadow-soft hover:shadow-medium transition-shadow"
              >
                <ChevronLeft className="h-5 w-5 text-medical-primary" />
              </button>
              <button
                onClick={nextArticle}
                className="p-2 rounded-full bg-white shadow-soft hover:shadow-medium transition-shadow"
              >
                <ChevronRight className="h-5 w-5 text-medical-primary" />
              </button>
            </div>
          </div>
        </div>
        
        {/* Container de artigos com largura total */}
        <div className="w-full">
          <div 
            ref={scrollContainerRef}
            className="flex gap-6 overflow-x-auto scrollbar-hide pb-4 px-4"
            style={{ scrollBehavior: 'smooth' }}
          >
            {artigos.map((artigo, index) => (
              <article 
                key={index}
                className="bg-white rounded-lg shadow-soft overflow-hidden hover:shadow-medium transition-all duration-300 cursor-pointer flex-shrink-0 w-80"
                onClick={() => setSelectedArticle(artigo)}
              >
                <div className="h-48 overflow-hidden">
                  <img 
                    src={artigo.imagem}
                    alt={artigo.titulo}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <div className="text-sm text-medical-secondary mb-2">
                    {artigo.data}
                  </div>
                  <h3 className="text-xl font-sans font-bold text-medical-primary mb-3 line-clamp-2">
                    {artigo.titulo}
                  </h3>
                  <p className="text-medical-secondary text-sm mb-4 line-clamp-2">
                    {artigo.subtitulo}
                  </p>
                  <button className="text-medical-primary hover:text-medical-secondary transition-colors font-medium text-sm">
                    LEIA MAIS »
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>

      {/* Segundo botão de agendamento */}
      <div className="py-12 bg-background">
        <div className="max-w-4xl mx-auto px-4 flex justify-center">
          <WhatsAppButton />
        </div>
      </div>

      {/* Botão flutuante WhatsApp */}
      <FloatingWhatsAppButton />

      {/* Footer */}
      <Footer
        logo={
          <img 
            src="/lovable-uploads/logoimg.png" 
            alt="Instituto de Olhos Santa Luzia" 
            className="h-10 w-10 brightness-0 invert"
          />
        }
        brandName="Instituto de Olhos Santa Luzia"
        socialLinks={[
          {
            icon: <Instagram className="h-5 w-5" />,
            href: "https://www.instagram.com/io.santaluzia/",
            label: "Instagram",
          },
          {
            icon: <Facebook className="h-5 w-5" />,
            href: "https://www.facebook.com/institudodeolhossantaluzia",
            label: "Facebook",
          },
        ]}
        mainLinks={[
          { href: "/instituto", label: "O Instituto" },
          { href: "/corpo-clinico", label: "Corpo Clínico" },
          { href: "/exames", label: "Exames" },
          { href: "/catarata", label: "Catarata" },
          { href: "/cirurgia-refrativa", label: "Cirurgia Refrativa" },
          { href: "/ceratocone", label: "Ceratocone" },
          { href: "/artigos", label: "Artigos" },
        ]}
        legalLinks={[
          { href: "#", label: "Política de Privacidade" },
          { href: "#", label: "Termos de Uso" },
          { href: "#", label: "LGPD" },
        ]}
        copyright={{
          text: "© 2024 Instituto de Olhos Santa Luzia",
          license: "Avenida dos Tarumãs, 930 - Sinop/MT - CEP: 78550-001 | +55 66 99721-5000",
        }}
      />

      <ArticleModal
        isOpen={!!selectedArticle}
        onClose={() => setSelectedArticle(null)}
        title={selectedArticle?.titulo || ""}
        content={selectedArticle?.conteudo || ""}
        date={selectedArticle?.data || ""}
      />
    </div>
  );
};

export default Home;
