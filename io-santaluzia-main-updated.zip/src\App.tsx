
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Instituto from "./pages/Instituto";
import Historia from "./pages/Historia";
import CorpoClinico from "./pages/CorpoClinico";
import Exames from "./pages/Exames";
import Catarata from "./pages/Catarata";
import CirurgiaRefrativa from "./pages/CirurgiaRefrativa";
import Ceratocone from "./pages/Ceratocone";
import Artigos from "./pages/Artigos";
import NotFound from "./pages/NotFound";
import AdminDashboard from "./pages/AdminDashboard";
import PatientPortal from "./pages/PatientPortal";
import OftalmologistaSinop from "./pages/OftalmologistaSinop";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/instituto" element={<Instituto />} />
          <Route path="/historia" element={<Historia />} />
          <Route path="/corpo-clinico" element={<CorpoClinico />} />
          <Route path="/exames" element={<Exames />} />
          <Route path="/catarata" element={<Catarata />} />
          <Route path="/cirurgia-refrativa" element={<CirurgiaRefrativa />} />
          <Route path="/ceratocone" element={<Ceratocone />} />
          <Route path="/artigos" element={<Artigos />} />
          <Route path="/portal-paciente" element={<PatientPortal />} />
          <Route path="/admin-dashboard-santa-luzia" element={<AdminDashboard />} />
          <Route path="/oftalmologista-sinop" element={<OftalmologistaSinop />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
